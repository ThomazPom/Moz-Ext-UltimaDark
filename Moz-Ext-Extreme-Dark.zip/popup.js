var defaultRgx =  ["http://*/*", "https://*/*"].join('\n')

var myPort = browser.runtime.connect({name:"port-from-cs"});



window.onload= function()
{

}
