# UltimaDark
This repository stores the source code for the UltimaDark Firefox extension
The extension uses agressive techniques to get a dark mode everywhere on internet
This is still highly experimental so it can also ruin your internet experience

# Compatibility
- Firefox Quantum 48+

# Versions

- 1.0
# Downloads
- [Download with firefox](https://addons.mozilla.org/fr/firefox/addon/UltimaDark/)

# How To Clone

```
git clone https://github.com/ThomazPom/Moz-Ext-UltimaDark
````
# Prerequisite

- No script has to be executed
- You only need Firefox installed on any platform
